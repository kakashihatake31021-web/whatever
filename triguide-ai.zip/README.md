# 🚀 TriGuide AI
> *"One Chatbot. Three Domains. Open Platform."*

A developer copilot and programming intelligence platform built with the **Google Gemini API**. Designed to bridge the gap between learning to code, fixing real-world mistakes, and building production-ready architectures.

---

## 🌟 The Big Idea & Problem Statement

Aspiring programmers and seasoned developers alike face three disconnected workflows:
1. **Learning Concepts**: Trapped in dense documentation or lengthy video tutorials without interactive, adaptive feedback.
2. **Debugging Errors**: Copy-pasting cryptic stack traces across search engines, struggling to pinpoint the root-cause line or see clean before/after diffs.
3. **Practicing & Building**: Switching to separate platforms to practice algorithms, generate boilerplates, or adapt code across languages.

**TriGuide AI** unifies all three needs into a single responsive, beautiful open platform.

---

## 🏛️ The Three Domains

```
                       ┌──────────────────────┐
                       │     TriGuide AI      │
                       │   "One Chatbot"      │
                       └──────────┬───────────┘
            ┌─────────────────────┼─────────────────────┐
            ▼                     ▼                     ▼
┌──────────────────────┐┌──────────────────────┐┌──────────────────────┐
│  Domain 1: 🎓 LEARN  ││  Domain 2: 🛠️ DEBUG  ││  Domain 3: 🚀 BUILD  │
│  Concept Tutor       ││  Code Doctor & Diffs ││  Practice & Arena    │
└──────────────────────┘└──────────────────────┘└──────────────────────┘
            │                     │                     │
            └─────────────────────┴─────────────────────┘
                                  │
                                  ▼
                     ┌──────────────────────────┐
                     │ Google Gemini API Engine │
                     │  (1.5 / 2.0 Flash / Pro) │
                     └──────────────────────────┘
```

### 1. 🎓 Domain 1: Code Mentor & Concept Tutor
- **Adaptive Explanation Depths**:
  - *Beginner (ELI5)*: Real-world analogies (e.g. Russian dolls for recursion, café queues for event loops) with zero jargon.
  - *Intermediate*: Clean idiomatic code and design patterns.
  - *Senior*: Memory layout, asymptotic complexity, compiler optimization, and trade-offs.
- **Multi-Language Support**: Python, JavaScript, TypeScript, C++, Java, Rust, Go, SQL, HTML/CSS.
- **Interactive Concept Verification**: Ends explanations with mini comprehension check puzzles.

### 2. 🛠️ Domain 2: Bug Doctor & Error Fixer
- **Side-by-Side Code Doctor Workspace**:
  - **Left Pane**: Buggy code editor with pre-loaded samples (*JS TypeError*, *Python IndexError*, *C++ Memory Leak*).
  - **Right Pane**: Line-by-line visual diff (+ added in green, - removed in red with line numbering).
- **Deep Root-Cause Diagnostics**: Explains *why* the bug occurred at the AST/runtime level, not just what was changed.
- **1-Click Clean Code Copy**: Instant copy of the verified, sanitized fix.

### 3. 🚀 Domain 3: Practice Arena & Project Architect
- **Algorithm Arena**: Optimal solutions to classic interview challenges (e.g., Two Sum via $O(n)$ hash map, Binary Search, LRU Cache) with time & space complexity breakdowns.
- **Architecture Boilerplates**: Ready-to-run REST APIs, validation middleware, and service layers.
- **Cross-Language Translation**: Seamlessly translate algorithms between Python, C++, TypeScript, and more.

---

## 🌐 Open Platform Features

- **Gemini API Model Flexibility**: Supports `gemini-1.5-flash` (lightning fast), `gemini-2.0-flash`, and `gemini-1.5-pro` (deep reasoning).
- **Smart Demo Simulator Mode**: Evaluators and judges can test every feature instantly without needing an API key.
- **Speech-to-Text Input**: Ask coding questions hands-free via the Web Speech API.
- **Conversation Export**: One-click download of the complete chat session as clean Markdown (`.md`).
- **Privacy First**: API keys are saved exclusively in client-side `localStorage` and never transmitted to external third-party servers.

---

## 💻 Tech Stack & Architecture

- **Frontend**: Pure modern Vanilla HTML5, CSS3, ES6+ JavaScript (zero build step, zero heavy `node_modules`).
- **Design System**: Deep Space Dark Glassmorphism, tailored glowing domain color accents, and Google Fonts (`Inter` + `JetBrains Mono`).
- **API Engine**: Direct Google Gemini REST API with multi-turn conversation memory and system instructions.

---

## ⚡ Quick Start / How to Run

### Method 1: Instant Launcher (Windows)
Double-click `run_server.bat` in the project directory, then open `http://localhost:8000` in your browser.

### Method 2: Python Command
In PowerShell or Terminal:
```bash
py -m http.server 8000
```
Then visit:
```
http://localhost:8000
```

### Method 3: Direct File Open
You can also directly double-click `index.html` to open it in Chrome, Edge, Firefox, or Safari!

---

## 🏆 Hackathon Demo Script (for Judges)

1. **Tour the 3 Domains**:
   - Click **🎓 Learn** in the top navigation or sidebar.
   - Click the prompt chip: *"Explain Recursion with a real-life analogy"*.
   - Notice how TriGuide AI provides the Russian Doll metaphor and Python code.
2. **Experience Code Doctor & Visual Diffs**:
   - Click the **⚡ Code Doctor / Diff Lab** button on the top right of the workspace.
   - Select the sample: *"Sample: JS TypeError"*.
   - Click **Diagnose & Fix ⚡**.
   - Notice the side-by-side visual diff showing red removed lines and green added lines with optional chaining (`?.`) and nullish coalescing (`??`).
3. **Practice & Project Generation**:
   - Switch to **🚀 Practice & Build**.
   - Select *"Solve Two Sum with optimal O(n) Hash Map"*.
   - View the optimal hash map algorithm and Big-O complexity analysis.
4. **Settings & Custom Gemini API Key**:
   - Click **⚙️ Settings** in the top-right corner.
   - Enter your own Google Gemini API key to switch to live LLM mode, or keep **Smart Demo Simulator** enabled for instant offline evaluation!

---

## 👨‍💻 Team & License
Built with ❤️ for the Hackathon. Open Source under the MIT License.
